# 1. 整合的模块
1. Spring MVC
2. Mybatis（MySQL）

# 2. 存在的问题
1. MyBatis 初始化脚本 schema-mysql.sql 没有被执行
2. Velocity 结合 Bootstrap
